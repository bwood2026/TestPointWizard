{$FORM TDialog2Form, Dialog2.sfm}
uses
  Classes, Graphics, Controls, Forms, Dialogs, StdCtrls;

// ============================================================
// CP-036 Pressure Devices by Comparison
// Test Point Wizard v13 — Dialog 2: Tolerance & Master Attributes
// Author: B. Wood
//
// Changes from v12c:
//   - Single combined tolerance dropdown replaces separate
//     ASME Grade + Tolerance Type combos
//   - cbTolType removed entirely
//   - New dropdown categories:
//       Unknown (AL Default Grade B FS)
//       ASME Grade xx — ±x.xx% FS/Rdg
//       Custom Tolerance FS
//       Custom Tolerance % Rdg
//       Special 3-2-3
//   - edtCustomTol added — only used for Custom selections
//   - Resolution check added for Custom % Rdg
//   - Row 9 Accuracy: prefix added per Joe Gunn direction
//   - Unknown selection produces: Accuracy: Unknown — Grade B
//     Applied (AL Default per CP-036)
// ============================================================

procedure edtMinChange(Sender: TObject);
begin
  if Trim(edtMin.Text) = '' then
    edtMin.Color := clYellow
  else
    edtMin.Color := clWhite;
end;

procedure Form2Create(Sender: TObject);
begin
  edtMin.Text := '0';
  edtMin.Color := clWhite;
  edtMasterRes.Text := '';
  edtCustomTol.Text := '';

  // ── Single combined tolerance dropdown ────────────────────
  cbTol.Items.Clear;
  cbTol.Items.Add('Unknown — AL Default (Grade B ±2.00% FS)');
  cbTol.Items.Add('ASME Grade 4A — ±0.10% FS');
  cbTol.Items.Add('ASME Grade 3A — ±0.25% FS');
  cbTol.Items.Add('ASME Grade 2A — ±0.50% FS');
  cbTol.Items.Add('ASME Grade 1A — ±1.00% FS');
  cbTol.Items.Add('ASME Grade A — ±1.00% FS');
  cbTol.Items.Add('ASME Grade B — ±2.00% FS');
  cbTol.Items.Add('ASME Grade C — ±3.00% FS');
  cbTol.Items.Add('ASME Grade D — ±5.00% FS');
  cbTol.Items.Add('ASME Grade 5A — ±0.05% FS');
  cbTol.Items.Add('ASME Grade 5AR — ±0.05% Rdg');
  cbTol.Items.Add('ASME Grade 4AR — ±0.10% Rdg');
  cbTol.Items.Add('ASME Grade 3AR — ±0.25% Rdg');
  cbTol.Items.Add('ASME Grade 2AR — ±0.50% Rdg');
  cbTol.Items.Add('ASME Grade AR — ±1.00% Rdg');
  cbTol.Items.Add('ASME Grade BR — ±2.00% Rdg');
  cbTol.Items.Add('Custom Tolerance FS');
  cbTol.Items.Add('Custom Tolerance % Rdg');
  cbTol.Items.Add('Special 3-2-3');

  // Default to Unknown — AL Default at index 0
  cbTol.ItemIndex := 0;
end;

procedure btnCancelClick(Sender: TObject);
begin
  Close;
end;

procedure btnGenerateClick(Sender: TObject);
var
  GageID        : string;
  Company       : string;
  MaxVal        : Double;
  MinVal        : Double;
  FullRange     : Double;
  Units         : string;
  Resolution    : Integer;
  ResText       : string;
  UUTResVal     : Double;
  TolSelection  : string;
  TolPct        : Double;
  CustomPct     : Double;
  IsReading     : Boolean;
  Is323         : Boolean;
  IsUnknown     : Boolean;
  IsCustomFS    : Boolean;
  IsCustomRdg   : Boolean;
  Tol           : Double;
  Missing       : string;
  DateStr       : string;
  TabName       : string;
  Points        : array[0..7] of Double;
  TolPlus       : array[0..7] of Double;
  TolMinus      : array[0..7] of Double;
  Descs         : array[0..7] of string;
  i             : Integer;
  Seq           : Integer;
  SQL           : string;
  TolDesc       : string;
  Grade         : string;
  StartPos      : Integer;
  EndPos        : Integer;
  LowestPoint   : Double;
  LowestTol     : Double;
begin

  // ── Validation ────────────────────────────────────────────
  Missing := '';

  if Trim(edtMin.Text) = '' then
  begin
    Missing := Missing + '  - Minimum Value' + #13;
    edtMin.Color := clYellow;
  end
  else
    edtMin.Color := clWhite;

  if cbTol.ItemIndex < 0 then
    Missing := Missing + '  - Tolerance Selection' + #13;

  // Custom tolerance requires a value in edtCustomTol
  if (cbTol.ItemIndex >= 0) and
     ((cbTol.Text = 'Custom Tolerance FS') or
      (cbTol.Text = 'Custom Tolerance % Rdg')) then
  begin
    if Trim(edtCustomTol.Text) = '' then
    begin
      Missing := Missing + '  - Custom Tolerance % value' + #13;
      edtCustomTol.Color := clYellow;
    end
    else
      edtCustomTol.Color := clWhite;
  end
  else
    edtCustomTol.Color := clWhite;

  if Missing <> '' then
  begin
    ShowMessage(
      'The following required fields must be completed before ' +
      'test points can be generated:' + #13 + #13 +
      Missing
    );
    Exit;
  end;

  // ── Read values from equipment record ─────────────────────
  GageID  := LocatingEquipmentID;
  Company := LocatingEquipmentCompany;
  MaxVal  := StrToFloat(LookupEquipmentFieldText('ATTRIBUTE1'));
  Units   := LookupEquipmentFieldText('UNIT_MEASURE');
  MinVal  := StrToFloat(edtMin.Text);

  if Trim(edtMasterRes.Text) <> '' then
    ResText := Trim(edtMasterRes.Text)
  else
    ResText := LookupEquipmentFieldText('ATTRIBUTE2');

  if Pos('.', ResText) > 0 then
    Resolution := Length(ResText) - Pos('.', ResText)
  else
    Resolution := 0;

  // UUT resolution as numeric value for comparison
  if Trim(ResText) <> '' then
    UUTResVal := StrToFloat(ResText)
  else
    UUTResVal := 0;

  FullRange := MaxVal - MinVal;

  if MaxVal <= MinVal then
  begin
    ShowMessage(
      'Maximum value must be greater than Minimum value.' + #13 +
      'Please correct and try again.'
    );
    edtMin.Color := clYellow;
    Exit;
  end;

  // ── Parse tolerance selection ─────────────────────────────
  TolSelection := cbTol.Text;
  IsReading    := False;
  Is323        := False;
  IsUnknown    := False;
  IsCustomFS   := False;
  IsCustomRdg  := False;
  TolPct       := 0.0200;
  Grade        := '';

  if TolSelection = 'Unknown — AL Default (Grade B ±2.00% FS)' then
  begin
    IsUnknown := True;
    TolPct    := 0.0200;
    Grade     := 'B';
  end
  else if TolSelection = 'Special 3-2-3' then
    Is323 := True
  else if TolSelection = 'Custom Tolerance FS' then
  begin
    IsCustomFS := True;
    CustomPct  := StrToFloat(edtCustomTol.Text) / 100;
    TolPct     := CustomPct;
  end
  else if TolSelection = 'Custom Tolerance % Rdg' then
  begin
    IsCustomRdg := True;
    IsReading   := True;
    CustomPct   := StrToFloat(edtCustomTol.Text) / 100;
    TolPct      := CustomPct;

    // ── Resolution check for Custom % Rdg ────────────────
    // Tolerance at lowest test point (20% of range) must not
    // be less than UUT resolution — metrologically meaningless
    if UUTResVal > 0 then
    begin
      LowestPoint := MinVal + (0.20 * FullRange);
      LowestTol   := LowestPoint * CustomPct;
      if LowestTol < UUTResVal then
      begin
        ShowMessage(
          'WARNING: The custom % of reading tolerance at the lowest ' +
          'test point (' + FormatFloat('0.######', LowestPoint) + ' ' + Units + ') ' +
          'would be ' + FormatFloat('0.######', LowestTol) + ' ' + Units + '.' + #13 +
          'This is less than the UUT resolution of ' + ResText + ' ' + Units + '.' + #13 + #13 +
          'The tolerance cannot be smaller than what the instrument can resolve.' + #13 +
          'Please enter a larger % value or change the tolerance type.'
        );
        edtCustomTol.Color := clYellow;
        Exit;
      end;
    end;
  end
  else
  begin
    // ASME Grade selection — extract grade code
    // Format is "ASME Grade XX — ±x.xx% FS/Rdg"
    StartPos := Pos('Grade ', TolSelection) + 6;
    EndPos   := Pos(' —', TolSelection);
    if (StartPos > 6) and (EndPos > StartPos) then
      Grade := Copy(TolSelection, StartPos, EndPos - StartPos)
    else
      Grade := '';

    // Map grade to TolPct and IsReading
    if      Grade = '4A'  then TolPct := 0.0010
    else if Grade = '3A'  then TolPct := 0.0025
    else if Grade = '2A'  then TolPct := 0.0050
    else if Grade = '1A'  then TolPct := 0.0100
    else if Grade = 'A'   then TolPct := 0.0100
    else if Grade = 'B'   then TolPct := 0.0200
    else if Grade = 'C'   then TolPct := 0.0300
    else if Grade = 'D'   then TolPct := 0.0500
    else if Grade = '5A'  then TolPct := 0.0005
    else if Grade = '5AR' then begin TolPct := 0.0005; IsReading := True; end
    else if Grade = '4AR' then begin TolPct := 0.0010; IsReading := True; end
    else if Grade = '3AR' then begin TolPct := 0.0025; IsReading := True; end
    else if Grade = '2AR' then begin TolPct := 0.0050; IsReading := True; end
    else if Grade = 'AR'  then begin TolPct := 0.0100; IsReading := True; end
    else if Grade = 'BR'  then begin TolPct := 0.0200; IsReading := True; end;
  end;

  // ── Build dated tab name ──────────────────────────────────
  DateStr := ReturnFromSQL('SELECT FORMAT(GETDATE(), ''MMddyyyy'')');
  TabName := 'AL-CP036-' + DateStr;

  // ── Pre-calculate span tolerance if needed ────────────────
  if (not IsReading) and (not Is323) then
    Tol := FullRange * TolPct;

  // ── Define test points ────────────────────────────────────
  Points[0] := MinVal + (0.20 * FullRange);  Descs[0] := '20% of Full Scale (Ascending)';
  Points[1] := MinVal + (0.40 * FullRange);  Descs[1] := '40% of Full Scale (Ascending)';
  Points[2] := MinVal + (0.60 * FullRange);  Descs[2] := '60% of Full Scale (Ascending)';
  Points[3] := MinVal + (0.80 * FullRange);  Descs[3] := '80% of Full Scale (Ascending)';
  Points[4] := MinVal + (1.00 * FullRange);  Descs[4] := '100% of Full Scale (Ascending)';
  Points[5] := MinVal + (0.60 * FullRange);  Descs[5] := '60% of Full Scale (Descending)';
  Points[6] := MinVal + (0.40 * FullRange);  Descs[6] := '40% of Full Scale (Descending)';
  Points[7] := MinVal;                        Descs[7] := 'Return to Zero (Descending)';

  // ── Calculate tolerances per point ───────────────────────
  for i := 0 to 7 do
  begin
    if Points[i] = MinVal then
    begin
      TolPlus[i]  := 0;
      TolMinus[i] := 0;
    end
    else if Is323 then
    begin
      // 3-2-3: 3% outer thirds, 2% middle third, FS
      if (Points[i] < MinVal + (FullRange * 0.33)) or
         (Points[i] > MinVal + (FullRange * 0.66)) then
      begin
        TolPlus[i]  := Points[i] + (FullRange * 0.03);
        TolMinus[i] := Points[i] - (FullRange * 0.03);
      end
      else
      begin
        TolPlus[i]  := Points[i] + (FullRange * 0.02);
        TolMinus[i] := Points[i] - (FullRange * 0.02);
      end;
    end
    else if IsReading then
    begin
      Tol         := Points[i] * TolPct;
      TolPlus[i]  := Points[i] + Tol;
      TolMinus[i] := Points[i] - Tol;
    end
    else
    begin
      TolPlus[i]  := Points[i] + Tol;
      TolMinus[i] := Points[i] - Tol;
    end;
  end;

  // ── Clear existing rows for this tab only ─────────────────
  RunSQL(
    'DELETE FROM TESTPNTS ' +
    'WHERE GAGE_SN = ''' + GageID + ''' ' +
    'AND COMPANY = ''' + Company + ''' ' +
    'AND CAL_TYPE = ''' + TabName + ''''
  );

  // ── Insert 8 test point rows ──────────────────────────────
  Seq := 1;
  for i := 0 to 7 do
  begin
    SQL :=
      'INSERT INTO TESTPNTS ' +
      '(COMPANY, GAGE_SN, LINE_NO, LINE_DESCRIPTION, ' +
      'LINE_STANDARD, TOLERANCE1, TOLERANCE2, UNIT_MEASURE, ' +
      'NUM_RESOLUTION, CAL_TYPE) ' +
      'VALUES (' +
      '''' + Company + ''', ' +
      '''' + GageID + ''', ' +
      IntToStr(Seq) + ', ' +
      '''' + Descs[i] + ''', ' +
      FormatFloat('0.######', Points[i]) + ', ' +
      FormatFloat('0.######', TolPlus[i]) + ', ' +
      FormatFloat('0.######', TolMinus[i]) + ', ' +
      '''' + Units + ''', ' +
      IntToStr(Resolution) + ', ' +
      '''' + TabName + ''')';
    RunSQL(SQL);
    Seq := Seq + 1;
  end;

  // ── Set new tab as default ────────────────────────────────
  RunSQL(
    'UPDATE GAGES SET CAL_TYPE = ''' + TabName + ''' ' +
    'WHERE GAGE_SN = ''' + GageID + ''' ' +
    'AND COMPANY = ''' + Company + ''''
  );

  // ── Build Accuracy row description for row 9 ─────────────
  if IsUnknown then
    TolDesc := 'Accuracy: Unknown — Grade B Applied (AL Default per CP-036)'
  else if Is323 then
    TolDesc := 'Accuracy: Special 3-2-3 — 3%/2%/3% Full Scale'
  else if IsCustomFS then
    TolDesc := 'Accuracy: Custom — ' + edtCustomTol.Text + '% Full Scale'
  else if IsCustomRdg then
    TolDesc := 'Accuracy: Custom — ' + edtCustomTol.Text + '% of Reading'
  else if IsReading then
    TolDesc := 'Accuracy: ASME Grade ' + Grade + ' — ±' + FormatFloat('0.##', TolPct * 100) + '% of Reading'
  else
  begin
    if Grade = 'B' then
      TolDesc := 'Accuracy: ASME Grade B — ±2.00% Full Scale (AL Default per CP-036)'
    else
      TolDesc := 'Accuracy: ASME Grade ' + Grade + ' — ±' + FormatFloat('0.##', TolPct * 100) + '% Full Scale';
  end;

  // ── Insert row 9 — Accuracy documentation row ────────────
  // Only company, gage, line number, description and tab written
  // NUM_RESOLUTION explicitly NULL to suppress IS grid default
  RunSQL(
    'INSERT INTO TESTPNTS ' +
    '(COMPANY, GAGE_SN, LINE_NO, LINE_DESCRIPTION, ' +
    'NUM_RESOLUTION, CAL_TYPE) ' +
    'VALUES (' +
    '''' + Company + ''', ' +
    '''' + GageID + ''', ' +
    '9, ' +
    '''' + TolDesc + ''', ' +
    'NULL, ' +
    '''' + TabName + ''')'
  );

  RefreshTestPointsGrid;

  ShowMessage(
    'Test points written successfully.' + #13 +
    'Gage ID    : ' + GageID + #13 +
    'Company    : ' + Company + #13 +
    'Tolerance  : ' + TolSelection + #13 +
    'Range      : ' + edtMin.Text + ' to ' + LookupEquipmentFieldText('ATTRIBUTE1') + ' ' + Units + #13 +
    'Resolution : ' + ResText + #13 +
    'Tab        : ' + TabName + #13 +
    '9 test point rows written.'
  );

  Close;
end;

begin
end.
